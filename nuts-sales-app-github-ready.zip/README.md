# Nuts Sales App (GitHub-ready)

This package is prepared for GitHub Pages.

Files included:
- index.html
- manifest.webmanifest
- sw.js

Before uploading:
- Add your own `icon.png` in the same folder if you want the app icon.
- Then upload all files to the root of your GitHub Pages repository.

Notes:
- The uploaded `nuts_sales_app.html` in this chat was only a placeholder file.
- This package uses the latest full working single-file app available in the workspace as the GitHub-ready `index.html`.
